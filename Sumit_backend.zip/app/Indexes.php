<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Indexes extends Model
{
    //
}
